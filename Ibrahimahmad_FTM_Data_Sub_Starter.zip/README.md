# Ibrahimahmad F.T.M Data Sub

A mobile-friendly starter web app for a Nigerian data-selling business.

## Included
- MTN, Airtel, Glo, and 9mobile selection
- Sample data-plan menu
- Demo transaction PIN setup/check
- Demo order history stored in the current browser
- Responsive layout for phones

## Important
This is a front-end demo only. It does not take payments or deliver data. Prices are sample placeholders. Before taking real customer orders, connect a legitimate VTU/data API provider and a payment gateway through a secure backend. Never put provider API keys or secret payment keys in `app.js` or other browser files. The demo PIN is stored in browser local storage and is not suitable for real-money security.

## Deploy to Netlify
1. Extract the ZIP.
2. In Netlify, choose **Add new site** / **Deploy manually**.
3. Upload the extracted folder containing `index.html`, `style.css`, and `app.js` (or connect a GitHub repository after adding these files).
4. Open the generated site link and test it.
