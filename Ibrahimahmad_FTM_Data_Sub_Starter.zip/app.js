const plans = {
  MTN: [{label:"500 MB — ₦150 (sample)",price:150},{label:"1 GB — ₦300 (sample)",price:300},{label:"2 GB — ₦600 (sample)",price:600}],
  Airtel: [{label:"500 MB — ₦150 (sample)",price:150},{label:"1 GB — ₦300 (sample)",price:300},{label:"2 GB — ₦600 (sample)",price:600}],
  Glo: [{label:"500 MB — ₦150 (sample)",price:150},{label:"1 GB — ₦300 (sample)",price:300},{label:"2 GB — ₦600 (sample)",price:600}],
  "9mobile": [{label:"500 MB — ₦150 (sample)",price:150},{label:"1 GB — ₦300 (sample)",price:300},{label:"2 GB — ₦600 (sample)",price:600}]
};
const $ = id => document.getElementById(id);
const network = $("network"), plan = $("plan"), message = $("message");
$("year").textContent = new Date().getFullYear();

function getOrders(){ try{return JSON.parse(localStorage.getItem("ftmOrders")||"[]")}catch{return []} }
function renderOrders(){
  const orders=getOrders(), root=$("orders");
  if(!orders.length){root.className="orders-empty";root.textContent="No orders yet.";return}
  root.className="";
  root.innerHTML=orders.map(o=>`<div class="order"><strong>${escapeHtml(o.network)} · ${escapeHtml(o.plan)}</strong><small>${escapeHtml(o.phone)} · ${escapeHtml(o.date)}</small><br><span class="status">DEMO — NOT SENT</span></div>`).join("");
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
network.addEventListener("change",()=>{
  plan.innerHTML='<option value="">Choose data plan</option>';
  (plans[network.value]||[]).forEach((p,i)=>{const o=document.createElement("option");o.value=String(i);o.textContent=p.label;plan.appendChild(o)});
  plan.disabled=!network.value;
});
$("pinSettings").addEventListener("click",()=>{$("pinMessage").textContent="";$("pinDialog").showModal()});
$("savePin").addEventListener("click",e=>{
  const a=$("newPin").value,b=$("confirmPin").value;
  if(!/^\d{4}$/.test(a)||a!==b){e.preventDefault();$("pinMessage").textContent="Enter matching 4-digit PINs.";return}
  localStorage.setItem("ftmDemoPin",a);
});
$("orderForm").addEventListener("submit",e=>{
  e.preventDefault();message.textContent="";
  const savedPin=localStorage.getItem("ftmDemoPin");
  if(!savedPin){message.textContent="Please tap Set PIN and create a demo PIN first.";return}
  if($("pin").value!==savedPin){message.textContent="Incorrect demo PIN.";return}
  const phone=$("phone").value.trim();
  if(!/^0\d{10}$/.test(phone)){message.textContent="Enter a valid 11-digit Nigerian phone number.";return}
  const chosen=(plans[network.value]||[])[Number(plan.value)];
  if(!chosen){message.textContent="Please choose a data plan.";return}
  const orders=getOrders();
  orders.unshift({network:network.value,plan:chosen.label,phone,date:new Date().toLocaleString()});
  localStorage.setItem("ftmOrders",JSON.stringify(orders.slice(0,10)));
  renderOrders();
  message.textContent="Demo order saved. No payment was taken and no data was delivered.";
  $("orderForm").reset();plan.disabled=true;plan.innerHTML='<option value="">Choose network first</option>';
});
$("clearOrders").addEventListener("click",()=>{localStorage.removeItem("ftmOrders");renderOrders()});
renderOrders();
